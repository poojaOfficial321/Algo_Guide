package com.dlight.algoguide.adapter

import com.dlight.algoguide.model.Courses
import androidx.recyclerview.widget.RecyclerView

class CoursesAdapter(private val courseList: List<Courses>) : RecyclerView.Adapter<CoursesAdapter.ViewHolder>() {

}