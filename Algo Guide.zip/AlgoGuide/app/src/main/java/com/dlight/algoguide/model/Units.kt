package com.dlight.algoguide.model

data class Units(var unit_id: String? =null,
            var unit_title: String? = null)
